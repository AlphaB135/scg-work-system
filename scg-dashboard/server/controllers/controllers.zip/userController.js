// File: server/controllers/userController.js
import prisma from '../utils/prismaClient.js';

export const getAllUsers = async (req, res) => {
  try {
    const users = await prisma.user.findMany({
      where: { role: 'EMPLOYEE' },
      select: {
        id: true,
        username: true,
        fullName: true,
        email: true,
        position: true,
        department: true,
        createdAt: true,
      },
    });

    // ✅ บันทึก log การเข้าถึงข้อมูลพนักงาน
    await prisma.adminLog.create({
      data: {
        adminId: req.user.userId,
        action: 'VIEW_USERS',
        details: `เข้าดูข้อมูลพนักงานทั้งหมด`,
      },
    });

    res.json(users);
  } catch (error) {
    console.error('Error fetching users:', error);
    res.status(500).json({ message: 'ไม่สามารถดึงข้อมูลพนักงานได้' });
  }
};
