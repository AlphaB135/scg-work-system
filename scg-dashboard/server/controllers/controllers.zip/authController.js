import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import prisma from '../utils/prismaClient.js';

// Login function
export const login = async (req, res) => {
  const { username, password } = req.body;
  try {
    // ตรวจสอบผู้ใช้จากฐานข้อมูล
    const user = await prisma.user.findUnique({ where: { username } });
    if (!user) return res.status(401).json({ message: 'ไม่พบผู้ใช้' });

    // ตรวจสอบรหัสผ่าน
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(401).json({ message: 'รหัสผ่านไม่ถูกต้อง' });

    // สร้าง JWT token
    const token = jwt.sign({ userId: user.id, role: user.role }, process.env.JWT_SECRET, {
      expiresIn: '3d', // กำหนดอายุของ token
    });

    // ส่ง token ผ่าน cookie แบบ httpOnly
    res.cookie('token', token, {
      httpOnly: true, // ป้องกันไม่ให้ JavaScript เข้าถึง cookie
      secure: process.env.NODE_ENV === 'production', // ใช้ https เมื่อ production
      sameSite: 'Lax', // ป้องกันการส่ง cookie ข้าม site
      maxAge: 3 * 24 * 60 * 60 * 1000, // กำหนดอายุของ cookie เป็น 3 วัน
    });

    // ส่งข้อมูลผู้ใช้กลับไปที่ frontend
    res.json({
      fullName: user.fullName,
      role: user.role,
    });
  } catch (error) {
    res.status(500).json({ message: 'เกิดข้อผิดพลาด', error });
  }
};


// Logout function
export const logout = (req, res) => {
  // ลบ cookie 'token' ที่เก็บไว้
  res.clearCookie('token', { httpOnly: true, secure: process.env.NODE_ENV === 'production' });
  res.json({ message: 'ออกจากระบบสำเร็จ' });
};
