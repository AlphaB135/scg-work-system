import prisma from '../utils/prismaClient.js';

export const getMyWorkRecords = async (req, res) => {
  const userId = req.user.userId;

  try {
    const records = await prisma.workRecord.findMany({
      where: { userId },
      orderBy: { date: 'asc' }
    });

    res.json(records);
  } catch (error) {
    console.error('Error fetching work records:', error);
    res.status(500).json({ message: 'ไม่สามารถดึงข้อมูลการทำงานได้' });
  }
};
